from django.apps import AppConfig


class PresenceConfig(AppConfig):
    name = 'presence'
