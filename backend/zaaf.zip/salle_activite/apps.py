from django.apps import AppConfig


class SalleActiviteConfig(AppConfig):
    name = 'salle_activite'
