from django.apps import AppConfig


class AbonnementConfig(AppConfig):
    name = 'abonnement'
