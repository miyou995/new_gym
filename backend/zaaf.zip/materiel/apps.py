from django.apps import AppConfig


class MaterielConfig(AppConfig):
    name = 'materiel'
