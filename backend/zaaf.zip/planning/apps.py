from django.apps import AppConfig


class PlanningConfig(AppConfig):
    name = 'planning'
