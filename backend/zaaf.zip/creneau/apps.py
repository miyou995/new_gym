from django.apps import AppConfig


class CreneauConfig(AppConfig):
    name = 'creneau'
