from django.apps import AppConfig


class SalleSportConfig(AppConfig):
    name = 'salle_sport'
